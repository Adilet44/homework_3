import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        double[] aspire = {1.4, -5.6, 5.4, -7.8, 4.5, -6.6, 2.3, -9.9, 1.7, -2.9, 2.6, -4.5, 7.5, -6.4, 6.9};
        System.out.println(Arrays.toString(aspire));
        for (double currentElem : aspire);

        }
    }

